# 📊 Sales & Demand Forecasting System

> A complete, business-ready machine learning pipeline for predicting future sales using historical data — built with Python, scikit-learn, and matplotlib.

![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-orange?logo=scikit-learn)
![License](https://img.shields.io/badge/license-MIT-green)

---

## ✨ What This Project Does

- **Cleans and prepares** time-series sales data from CSV
- **Engineers** trend, seasonal, lag, and rolling features
- **Decomposes** seasonality using the ratio-to-moving-average method
- **Trains** a Linear Regression model with interpretable coefficients
- **Evaluates** forecast quality with MAPE, RMSE, MAE, and R²
- **Projects** 6 months into the future with 90% confidence intervals
- **Visualises** everything in business-friendly charts exportable as PNG
- **Summarises** the forecast for non-technical stakeholders

---

## 📁 Project Structure

```
sales-forecasting/
├── data/
│   ├── generate_data.py          # Generates synthetic sample dataset
│   └── sample_sales_data.csv     # Auto-generated (run generate_data.py)
│
├── notebooks/
│   └── Sales_Demand_Forecasting.ipynb   # Main Jupyter notebook (start here)
│
├── src/
│   ├── forecaster.py             # Core ML engine (data prep, model, forecast)
│   ├── visualizer.py             # All matplotlib chart functions
│   └── run_forecast.py           # CLI entry point
│
├── tests/
│   └── test_forecaster.py        # 20+ unit tests (pytest)
│
├── outputs/                      # Auto-created — charts and forecast CSV
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Clone and install
```bash
git clone https://github.com/YOUR_USERNAME/sales-forecasting.git
cd sales-forecasting
pip install -r requirements.txt
```

### 2. Generate sample data
```bash
python data/generate_data.py
```

### 3. Open the notebook
```bash
jupyter notebook notebooks/Sales_Demand_Forecasting.ipynb
```
Run all cells top-to-bottom. Charts will save to `outputs/`.

### 4. Or run from the command line
```bash
# Forecast all products, all regions (6-month horizon)
python src/run_forecast.py

# Forecast a specific product and region
python src/run_forecast.py --product Electronics --region North --horizon 6

# Use your own CSV
python src/run_forecast.py --data path/to/your_data.csv
```

---

## 📋 Expected CSV Format

Your CSV must contain these columns (column names are case-sensitive):

| Column | Type | Description |
|--------|------|-------------|
| `date` | `YYYY-MM-DD` | Transaction or period date |
| `revenue` | float | Sales revenue in your currency |
| `units_sold` | int | Number of units sold |
| `product_category` | str | Product group label |
| `region` | str | Geographic region |
| `marketing_spend` | float | Optional — ad spend that period |
| `discount_pct` | float | Optional — average discount (0–1) |

> **Minimum requirement:** `date`, `revenue`, `units_sold`. Other columns are optional.

---

## 📊 Model Details

### Algorithm
**Multiplicative Seasonal Decomposition + Linear Regression**

```
Forecast(t) = Trend(t) × SeasonalIndex(month)
```

The Linear Regression learns from these features:

| Feature | What it captures |
|---------|-----------------|
| `trend_idx` | Long-term growth slope |
| `month_sin`, `month_cos` | Cyclical seasonal pattern (no ordinal bias) |
| `lag_1` | Revenue last month |
| `lag_3` | Revenue 3 months ago (quarter effect) |
| `lag_12` | Revenue same month last year |
| `rolling_3` | 3-month trailing average |
| `rolling_6` | 6-month trailing average |

### Seasonal decomposition
Uses the **ratio-to-moving-average** method:
1. Compute centred 12-month moving average (eliminates seasonality)
2. Divide actuals by the moving average (isolates seasonal ratio)
3. Average ratios by calendar month → seasonal index
4. Normalise so the 12 factors sum to 12

### Confidence intervals
```
Lower = Forecast − z × σ(t)
Upper = Forecast + z × σ(t)
σ(t) = |Forecast| × (0.06 + 0.015 × months_ahead)
```
At 90% confidence, z = 1.645. Uncertainty grows with forecast horizon.

---

## 📈 Evaluation Metrics

| Metric | Formula | Good threshold (retail) |
|--------|---------|------------------------|
| **MAPE** | mean(|actual−pred|/actual) × 100 | < 10% |
| **RMSE** | √mean((actual−pred)²) | Depends on scale |
| **MAE** | mean(|actual−pred|) | Depends on scale |
| **R²** | 1 − SS_res/SS_tot | > 0.85 |

The model is evaluated on a held-out test set (default: last 6 months) — data the model never saw during training.

---

## 🖼 Sample Outputs

All charts are saved to `outputs/` as high-resolution PNGs:

- `forecast_main.png` — Historical actuals + future forecast with confidence bands
- `seasonality_index.png` — Monthly demand index (which months are strong/weak)
- `error_analysis.png` — Residual bars + actual vs predicted scatter
- `category_breakdown.png` — Revenue by product category
- `forecast_table.png` — Printable forecast summary table
- `forecast_output.csv` — Machine-readable forecast data

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

The test suite covers 20+ scenarios including:
- MAPE edge cases (zeros, perfect predictions)
- Data preparation correctness
- Seasonal index normalisation
- Train/test split integrity
- Forecast horizon, band ordering, and confidence levels

---

## 🔧 Configuration

All parameters can be set at the top of the notebook or via CLI flags:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `PRODUCT` | `'All'` | Product category filter |
| `REGION` | `'All'` | Region filter |
| `HORIZON` | `6` | Months to forecast |
| `TEST_MONTHS` | `6` | Months held out for evaluation |
| `confidence` | `0.90` | Confidence interval level |

---

## 🚀 Upgrading the Model

| Upgrade | Library | When to use |
|---------|---------|-------------|
| Prophet | `pip install prophet` | Holiday effects, trend changepoints |
| SARIMA | `statsmodels` | Rigorous statistical framework |
| XGBoost | `pip install xgboost` | Non-linear patterns, many features |
| LSTM | `tensorflow` / `pytorch` | Long sequential dependencies |

---

## 🏢 Business Use Cases

This system is suitable for:

- **Retail stores** — plan inventory and avoid stockouts or overstock
- **E-commerce** — size warehouse capacity by month
- **Startups** — project revenue for investor reporting
- **Restaurants / F&B** — manage ingredient orders and staffing
- **Manufacturing** — schedule production runs ahead of demand peaks

---

## 📝 License

MIT License — free to use, modify, and distribute.

---

*Built as part of the [Future Interns](https://www.linkedin.com/company/future-interns/) Sales & Demand Forecasting project.*
