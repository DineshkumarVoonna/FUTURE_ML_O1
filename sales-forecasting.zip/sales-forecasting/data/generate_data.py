"""
generate_data.py
Generates a realistic synthetic sales dataset for forecasting demo.
Run this once to create sample_sales_data.csv in the data/ folder.
"""

import numpy as np
import pandas as pd
from datetime import datetime

np.random.seed(42)

PRODUCTS   = ["Electronics", "Apparel", "Home & Garden", "Food & Beverage"]
REGIONS    = ["North", "South", "East", "West"]
BASE_SALES = {"Electronics": 72000, "Apparel": 45000,
              "Home & Garden": 38000, "Food & Beverage": 30000}
GROWTH     = {"Electronics": 0.22, "Apparel": 0.12,
              "Home & Garden": 0.25, "Food & Beverage": 0.09}
SEASON_IDX = [0.72, 0.68, 0.81, 0.88, 0.95, 0.97,
              0.93, 0.96, 1.02, 1.12, 1.48, 1.68]

rows = []
start = datetime(2022, 1, 1)

for product in PRODUCTS:
    base   = BASE_SALES[product]
    growth = GROWTH[product]
    for i in range(36):          # 3 years of monthly history
        date = pd.Timestamp(start) + pd.DateOffset(months=i)
        trend   = base * (1 + growth * i / 12)
        season  = SEASON_IDX[date.month - 1]
        noise   = np.random.normal(0, 0.08)
        units   = max(10, int(trend * season * (1 + noise) / 150))
        revenue = max(100, round(trend * season * (1 + noise), 2))
        for region in REGIONS:
            r_factor = {"North": 1.05, "South": 0.90,
                        "East": 1.12, "West": 0.93}[region]
            r_noise  = np.random.normal(0, 0.05)
            rows.append({
                "date":            date.strftime("%Y-%m-%d"),
                "product_category": product,
                "region":          region,
                "units_sold":      max(1, int(units * r_factor * (1 + r_noise))),
                "revenue":         round(revenue * r_factor * (1 + r_noise) / 4, 2),
                "marketing_spend": round(np.random.uniform(500, 5000), 2),
                "discount_pct":    round(np.random.uniform(0, 0.25), 3),
                "returns":         max(0, int(np.random.poisson(units * 0.03))),
            })

df = pd.DataFrame(rows)
df.to_csv("data/sample_sales_data.csv", index=False)
print(f"✅  Generated {len(df):,} rows → data/sample_sales_data.csv")
print(df.head())
