"""
src/forecaster.py
Core forecasting engine: data preparation, seasonal decomposition,
model training, evaluation, and future projection.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings("ignore")


# ── helpers ──────────────────────────────────────────────────────────────────

def mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean Absolute Percentage Error (%)."""
    mask = y_true != 0
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)


# ── data preparation ──────────────────────────────────────────────────────────

def load_and_prepare(
    filepath: str,
    product: str = "All",
    region: str = "All",
) -> pd.DataFrame:
    """
    Load raw CSV, filter by product/region, aggregate to monthly totals,
    and engineer time-based features.

    Parameters
    ----------
    filepath : str
        Path to the sales CSV file.
    product  : str
        Product category to filter; 'All' to aggregate all categories.
    region   : str
        Region to filter; 'All' to aggregate all regions.

    Returns
    -------
    pd.DataFrame with columns:
        date, revenue, units_sold, month, month_sin, month_cos,
        trend_idx, lag_1, lag_3, lag_12, rolling_3, rolling_6
    """
    df = pd.read_csv(filepath, parse_dates=["date"])

    if product != "All":
        df = df[df["product_category"] == product]
    if region != "All":
        df = df[df["region"] == region]

    monthly = (
        df.groupby(pd.Grouper(key="date", freq="MS"))
          .agg(revenue=("revenue", "sum"),
               units_sold=("units_sold", "sum"),
               marketing_spend=("marketing_spend", "sum"),
               discount_pct=("discount_pct", "mean"))
          .reset_index()
          .sort_values("date")
    )

    # ── time features ────────────────────────────────────────────────────────
    monthly["month"]      = monthly["date"].dt.month
    monthly["year"]       = monthly["date"].dt.year
    monthly["trend_idx"]  = np.arange(len(monthly))          # 0, 1, 2, …

    # cyclical encoding of month (avoids ordinal assumption)
    monthly["month_sin"]  = np.sin(2 * np.pi * monthly["month"] / 12)
    monthly["month_cos"]  = np.cos(2 * np.pi * monthly["month"] / 12)

    # ── lag features ─────────────────────────────────────────────────────────
    monthly["lag_1"]      = monthly["revenue"].shift(1)
    monthly["lag_3"]      = monthly["revenue"].shift(3)
    monthly["lag_12"]     = monthly["revenue"].shift(12)
    monthly["rolling_3"]  = monthly["revenue"].shift(1).rolling(3).mean()
    monthly["rolling_6"]  = monthly["revenue"].shift(1).rolling(6).mean()

    monthly.dropna(inplace=True)
    monthly.reset_index(drop=True, inplace=True)
    return monthly


# ── seasonal decomposition ────────────────────────────────────────────────────

def compute_seasonal_index(df: pd.DataFrame) -> np.ndarray:
    """
    Classic ratio-to-moving-average seasonal index.
    Returns array of length 12 (one factor per calendar month).
    """
    # centred 12-month moving average
    ma = df["revenue"].rolling(12, center=True).mean()
    ratios = df["revenue"] / ma
    seasonal = np.array([
        ratios[df["month"] == m].mean() for m in range(1, 13)
    ])
    # normalise so factors sum to 12
    seasonal = seasonal / seasonal.mean()
    return seasonal


# ── model training ────────────────────────────────────────────────────────────

FEATURES = ["trend_idx", "month_sin", "month_cos",
            "lag_1", "lag_3", "lag_12", "rolling_3", "rolling_6"]


def train(df: pd.DataFrame, test_months: int = 6):
    """
    Fit a LinearRegression on the training split.

    Parameters
    ----------
    df          : prepared monthly DataFrame
    test_months : number of tail months held out for evaluation

    Returns
    -------
    model        : fitted sklearn LinearRegression
    train_df     : training slice
    test_df      : test slice
    """
    train_df = df.iloc[:-test_months].copy()
    test_df  = df.iloc[-test_months:].copy()

    X_train = train_df[FEATURES]
    y_train = train_df["revenue"]

    model = LinearRegression()
    model.fit(X_train, y_train)
    return model, train_df, test_df


# ── evaluation ────────────────────────────────────────────────────────────────

def evaluate(model, test_df: pd.DataFrame) -> dict:
    """
    Compute MAPE, RMSE, MAE, R² on the held-out test set.
    Returns a dict of metrics plus arrays of actuals and predictions.
    """
    X_test  = test_df[FEATURES]
    y_true  = test_df["revenue"].values
    y_pred  = model.predict(X_test)

    return {
        "mape"      : round(mape(y_true, y_pred), 2),
        "rmse"      : round(np.sqrt(mean_squared_error(y_true, y_pred)), 2),
        "mae"       : round(np.mean(np.abs(y_true - y_pred)), 2),
        "r2"        : round(r2_score(y_true, y_pred), 4),
        "y_true"    : y_true,
        "y_pred"    : y_pred,
        "residuals" : y_true - y_pred,
        "dates"     : test_df["date"].values,
    }


# ── forecasting ───────────────────────────────────────────────────────────────

def forecast_future(
    model,
    df: pd.DataFrame,
    seasonal_index: np.ndarray,
    horizon: int = 6,
    confidence: float = 0.90,
) -> pd.DataFrame:
    """
    Project `horizon` months beyond the last date in df.

    Strategy:
      - The linear trend is extrapolated via trend_idx continuation.
      - Cyclical month features are computed analytically.
      - Lag features are seeded from the last known actuals, then
        chained forward using previous forecasts.
      - Confidence bands are ±z * growing_sigma, where sigma widens
        proportionally with the forecast horizon.

    Returns a DataFrame with columns:
        date, forecast, lower, upper, seasonal_factor
    """
    z = {0.90: 1.645, 0.95: 1.960, 0.99: 2.576}.get(confidence, 1.645)

    last_row   = df.iloc[-1]
    last_date  = pd.Timestamp(last_row["date"])
    last_trend = int(last_row["trend_idx"])

    # seed rolling history with last known values
    history = list(df["revenue"].values[-12:])

    rows = []
    for h in range(1, horizon + 1):
        future_date  = last_date + pd.DateOffset(months=h)
        month        = future_date.month
        t_idx        = last_trend + h
        month_sin    = np.sin(2 * np.pi * month / 12)
        month_cos    = np.cos(2 * np.pi * month / 12)

        lag_1        = history[-1]
        lag_3        = history[-3]  if len(history) >= 3  else history[0]
        lag_12       = history[-12] if len(history) >= 12 else history[0]
        rolling_3    = np.mean(history[-3:])  if len(history) >= 3  else history[-1]
        rolling_6    = np.mean(history[-6:])  if len(history) >= 6  else history[-1]

        X = np.array([[t_idx, month_sin, month_cos,
                       lag_1, lag_3, lag_12, rolling_3, rolling_6]])
        pt = float(model.predict(X)[0])

        # confidence band widens with horizon
        sigma  = abs(pt) * (0.06 + 0.015 * h)
        lower  = pt - z * sigma
        upper  = pt + z * sigma

        rows.append({
            "date"            : future_date,
            "forecast"        : round(max(0, pt), 2),
            "lower"           : round(max(0, lower), 2),
            "upper"           : round(upper, 2),
            "seasonal_factor" : round(seasonal_index[month - 1], 4),
        })
        history.append(pt)

    return pd.DataFrame(rows)
