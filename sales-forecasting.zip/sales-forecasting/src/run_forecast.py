"""
src/run_forecast.py
Command-line entry point.

Usage
-----
# forecast all products, all regions:
python src/run_forecast.py

# forecast a specific product and region:
python src/run_forecast.py --product Electronics --region North --horizon 6

# use your own CSV:
python src/run_forecast.py --data path/to/your_data.csv
"""

import argparse
import os
import sys

import pandas as pd

# allow running from the project root
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from forecaster  import (load_and_prepare, compute_seasonal_index,
                          train, evaluate, forecast_future)
from visualizer  import (plot_forecast, plot_seasonality, plot_residuals,
                          plot_category_breakdown, plot_forecast_table)


def parse_args():
    p = argparse.ArgumentParser(description="Sales & Demand Forecasting")
    p.add_argument("--data",     default="data/sample_sales_data.csv",
                   help="Path to the sales CSV file.")
    p.add_argument("--product",  default="All",
                   choices=["All","Electronics","Apparel",
                            "Home & Garden","Food & Beverage"],
                   help="Product category to forecast.")
    p.add_argument("--region",   default="All",
                   choices=["All","North","South","East","West"],
                   help="Region to filter.")
    p.add_argument("--horizon",  type=int, default=6,
                   help="Number of months to forecast (default: 6).")
    p.add_argument("--test",     type=int, default=6,
                   help="Months held out for model evaluation.")
    p.add_argument("--outdir",   default="outputs",
                   help="Directory to save charts and forecast CSV.")
    p.add_argument("--no-plots", action="store_true",
                   help="Skip saving charts (useful in headless environments).")
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    print("=" * 60)
    print("  Sales & Demand Forecasting System")
    print("=" * 60)

    # ── 1. load & prepare ────────────────────────────────────────────────────
    print(f"\n[1/5] Loading data from: {args.data}")
    df = load_and_prepare(args.data, product=args.product, region=args.region)
    print(f"      {len(df)} monthly records | "
          f"{df['date'].min().strftime('%b %Y')} → {df['date'].max().strftime('%b %Y')}")

    # ── 2. seasonal decomposition ────────────────────────────────────────────
    print("\n[2/5] Computing seasonal index …")
    raw_df = pd.read_csv(args.data, parse_dates=["date"])
    seasonal_index = compute_seasonal_index(df)
    months = ["Jan","Feb","Mar","Apr","May","Jun",
              "Jul","Aug","Sep","Oct","Nov","Dec"]
    for m, v in zip(months, seasonal_index):
        bar = "█" * int(v * 20)
        print(f"      {m}: {bar}  {v:.2f}x")

    # ── 3. train model ───────────────────────────────────────────────────────
    print(f"\n[3/5] Training model (test split: last {args.test} months) …")
    model, train_df, test_df = train(df, test_months=args.test)
    coef_df = pd.DataFrame(
        {"feature": ["trend_idx","month_sin","month_cos",
                     "lag_1","lag_3","lag_12","rolling_3","rolling_6"],
         "coefficient": model.coef_}
    ).sort_values("coefficient", key=abs, ascending=False)
    print("\n      Feature importance (linear coefficients):")
    print(coef_df.to_string(index=False))

    # ── 4. evaluate ──────────────────────────────────────────────────────────
    print(f"\n[4/5] Evaluating on test set …")
    metrics = evaluate(model, test_df)
    print(f"\n      ┌─────────────────────────────────┐")
    print(f"      │  MAPE  : {metrics['mape']:>8.2f} %           │")
    print(f"      │  RMSE  : ${metrics['rmse']:>12,.0f}        │")
    print(f"      │  MAE   : ${metrics['mae']:>12,.0f}        │")
    print(f"      │  R²    : {metrics['r2']:>8.4f}             │")
    print(f"      └─────────────────────────────────┘")

    # ── 5. forecast ──────────────────────────────────────────────────────────
    print(f"\n[5/5] Generating {args.horizon}-month forecast …\n")
    forecast_df = forecast_future(model, df, seasonal_index,
                                  horizon=args.horizon)
    print(forecast_df[["date","forecast","lower","upper"]].to_string(index=False))

    # save CSV
    csv_path = os.path.join(args.outdir, "forecast_output.csv")
    forecast_df.to_csv(csv_path, index=False)
    print(f"\n      ✅  Forecast saved → {csv_path}")

    # business summary
    avg_hist  = df["revenue"].tail(args.horizon).mean()
    avg_fc    = forecast_df["forecast"].mean()
    growth    = (avg_fc - avg_hist) / avg_hist * 100
    peak_row  = forecast_df.loc[forecast_df["forecast"].idxmax()]
    print(f"\n{'─'*60}")
    print("  📊  Business Planning Summary")
    print(f"{'─'*60}")
    print(f"  Avg monthly revenue (last {args.horizon} mo) : ${avg_hist:>12,.0f}")
    print(f"  Avg monthly forecast (next {args.horizon} mo): ${avg_fc:>12,.0f}")
    print(f"  Expected growth                 : {growth:>+.1f}%")
    print(f"  Peak forecast month             : "
          f"{pd.Timestamp(peak_row['date']).strftime('%B %Y')} "
          f"(${peak_row['forecast']:,.0f})")
    print(f"  Recommended inventory buffer    : "
          f"${peak_row['forecast'] * 0.12:,.0f}  (~12% of peak)")
    print(f"{'─'*60}\n")

    # ── charts ───────────────────────────────────────────────────────────────
    if not args.no_plots:
        import matplotlib
        matplotlib.use("Agg")   # headless backend

        tag = f"{args.product.replace(' ','_')}_{args.region}"

        fig1 = plot_forecast(df, forecast_df,
                             title=f"Sales Forecast — {args.product} / {args.region}")
        fig1.savefig(os.path.join(args.outdir, f"forecast_{tag}.png"),
                     dpi=150, bbox_inches="tight")

        fig2 = plot_seasonality(seasonal_index)
        fig2.savefig(os.path.join(args.outdir, "seasonality_index.png"),
                     dpi=150, bbox_inches="tight")

        fig3 = plot_residuals(metrics)
        fig3.savefig(os.path.join(args.outdir, "error_analysis.png"),
                     dpi=150, bbox_inches="tight")

        fig4 = plot_category_breakdown(raw_df)
        fig4.savefig(os.path.join(args.outdir, "category_breakdown.png"),
                     dpi=150, bbox_inches="tight")

        fig5 = plot_forecast_table(forecast_df)
        fig5.savefig(os.path.join(args.outdir, "forecast_table.png"),
                     dpi=150, bbox_inches="tight")

        print(f"  📁  Charts saved to: {args.outdir}/\n")


if __name__ == "__main__":
    main()
