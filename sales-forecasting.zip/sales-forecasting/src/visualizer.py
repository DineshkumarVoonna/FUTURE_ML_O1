"""
src/visualizer.py
All matplotlib / seaborn plotting functions used by the notebook and CLI.
Every function returns the Figure so callers can save or display it.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.dates as mdates
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# ── style ─────────────────────────────────────────────────────────────────────
PALETTE = {
    "actual"   : "#185FA5",
    "forecast" : "#3B6D11",
    "trend"    : "#E24B4A",
    "band"     : "#C0DD97",
    "positive" : "#3B6D11",
    "negative" : "#A32D2D",
    "neutral"  : "#888780",
}
MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun",
               "Jul","Aug","Sep","Oct","Nov","Dec"]

def _money(x, _):
    if abs(x) >= 1_000_000:
        return f"${x/1_000_000:.1f}M"
    if abs(x) >= 1_000:
        return f"${x/1_000:.0f}K"
    return f"${x:.0f}"

plt.rcParams.update({
    "figure.facecolor" : "white",
    "axes.facecolor"   : "white",
    "axes.spines.top"  : False,
    "axes.spines.right": False,
    "axes.grid"        : True,
    "grid.color"       : "#e8e8e8",
    "grid.linewidth"   : 0.6,
    "font.family"      : "DejaVu Sans",
    "axes.titlesize"   : 13,
    "axes.labelsize"   : 11,
    "xtick.labelsize"  : 10,
    "ytick.labelsize"  : 10,
})


# ── 1. main forecast chart ────────────────────────────────────────────────────

def plot_forecast(
    hist_df: pd.DataFrame,
    forecast_df: pd.DataFrame,
    title: str = "Sales Forecast",
) -> plt.Figure:
    """
    Line chart: historical actuals + trend + future forecast with
    confidence band.
    """
    fig, ax = plt.subplots(figsize=(14, 5))

    # actuals
    ax.plot(hist_df["date"], hist_df["revenue"],
            color=PALETTE["actual"], lw=2, label="Actual sales", zorder=3)

    # simple centred trend (12-mo rolling mean on history)
    trend = hist_df["revenue"].rolling(12, center=True, min_periods=1).mean()
    ax.plot(hist_df["date"], trend,
            color=PALETTE["trend"], lw=1.5, ls="--",
            alpha=0.75, label="Trend (12-mo MA)", zorder=2)

    # forecast
    ax.plot(forecast_df["date"], forecast_df["forecast"],
            color=PALETTE["forecast"], lw=2, ls="--", marker="o",
            ms=5, label="Forecast", zorder=4)

    # confidence band
    ax.fill_between(
        forecast_df["date"],
        forecast_df["lower"],
        forecast_df["upper"],
        color=PALETTE["band"], alpha=0.40, label="90% confidence band",
    )

    # vertical divider
    split = hist_df["date"].iloc[-1]
    ax.axvline(split, color="#aaaaaa", lw=1, ls=":")
    ax.text(split, ax.get_ylim()[1] * 0.97, "  forecast →",
            color="#888", fontsize=9, va="top")

    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_money))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    plt.xticks(rotation=35)
    ax.set_title(title, fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Month")
    ax.set_ylabel("Revenue")
    ax.legend(loc="upper left", fontsize=9, framealpha=0.6)
    fig.tight_layout()
    return fig


# ── 2. seasonality index ──────────────────────────────────────────────────────

def plot_seasonality(seasonal_index: np.ndarray) -> plt.Figure:
    """
    Bar chart of the 12-month seasonal index.
    Bars coloured by intensity; baseline at 1.0 shown as a dashed line.
    """
    fig, ax = plt.subplots(figsize=(10, 4))
    colors = [
        PALETTE["actual"] if v >= 1.2 else
        "#378ADD"         if v >= 1.0 else
        "#85B7EB"         if v >= 0.9 else
        "#B5D4F4"
        for v in seasonal_index
    ]
    bars = ax.bar(MONTH_NAMES, seasonal_index, color=colors,
                  edgecolor="white", linewidth=0.5, zorder=3)
    ax.axhline(1.0, color=PALETTE["trend"], lw=1.5, ls="--",
               label="Baseline (1.0x)", zorder=4)

    for bar, v in zip(bars, seasonal_index):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.02,
                f"{v:.2f}x", ha="center", va="bottom", fontsize=9)

    ax.set_ylim(0.5, 1.95)
    ax.set_title("Seasonality Index by Month", fontsize=14,
                 fontweight="bold", pad=10)
    ax.set_ylabel("Index (1.0 = average)")
    ax.legend(fontsize=9)
    fig.tight_layout()
    return fig


# ── 3. residual / error analysis ──────────────────────────────────────────────

def plot_residuals(eval_results: dict) -> plt.Figure:
    """Two-panel: residual bar chart + actual vs predicted scatter."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 4))

    # panel 1 – residuals
    dates   = pd.to_datetime(eval_results["dates"])
    resids  = eval_results["residuals"]
    colors  = [PALETTE["positive"] if r >= 0 else PALETTE["negative"]
                for r in resids]
    ax1.bar(range(len(resids)), resids, color=colors,
            edgecolor="white", linewidth=0.5, zorder=3)
    ax1.axhline(0, color="#aaa", lw=1)
    ax1.set_xticks(range(len(resids)))
    ax1.set_xticklabels(
        [d.strftime("%b '%y") for d in dates], rotation=35, ha="right")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(_money))
    ax1.set_title("Residuals (Actual − Predicted)", fontweight="bold")
    ax1.set_ylabel("Error")
    legend_patches = [
        Patch(facecolor=PALETTE["positive"], label="Over-predicted"),
        Patch(facecolor=PALETTE["negative"], label="Under-predicted"),
    ]
    ax1.legend(handles=legend_patches, fontsize=8)

    # panel 2 – actual vs predicted
    y_true = eval_results["y_true"]
    y_pred = eval_results["y_pred"]
    lims   = [min(y_true.min(), y_pred.min()) * 0.95,
              max(y_true.max(), y_pred.max()) * 1.05]
    ax2.scatter(y_true, y_pred, color=PALETTE["actual"],
                edgecolors="white", s=70, zorder=3)
    ax2.plot(lims, lims, color="#aaa", lw=1, ls="--", label="Perfect fit")
    ax2.set_xlim(lims); ax2.set_ylim(lims)
    ax2.xaxis.set_major_formatter(mticker.FuncFormatter(_money))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(_money))
    ax2.set_title("Actual vs Predicted", fontweight="bold")
    ax2.set_xlabel("Actual Revenue")
    ax2.set_ylabel("Predicted Revenue")
    ax2.legend(fontsize=9)

    fig.suptitle("Model Error Analysis", fontsize=14,
                 fontweight="bold", y=1.02)
    fig.tight_layout()
    return fig


# ── 4. category breakdown ─────────────────────────────────────────────────────

def plot_category_breakdown(df: pd.DataFrame) -> plt.Figure:
    """Horizontal bar chart of revenue by product category."""
    rev_by_cat = (
        df.groupby("product_category")["revenue"].sum()
          .sort_values(ascending=True)
    )
    fig, ax = plt.subplots(figsize=(8, 3.5))
    colors = ["#185FA5", "#378ADD", "#85B7EB", "#B5D4F4"]
    bars = ax.barh(rev_by_cat.index, rev_by_cat.values,
                   color=colors, edgecolor="white", linewidth=0.5)
    for bar, val in zip(bars, rev_by_cat.values):
        ax.text(val + rev_by_cat.values.max() * 0.01,
                bar.get_y() + bar.get_height() / 2,
                _money(val, None), va="center", fontsize=10)
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(_money))
    ax.set_title("Revenue by Product Category (All Time)",
                 fontsize=13, fontweight="bold", pad=10)
    ax.set_xlabel("Total Revenue")
    fig.tight_layout()
    return fig


# ── 5. forecast summary table ─────────────────────────────────────────────────

def plot_forecast_table(forecast_df: pd.DataFrame) -> plt.Figure:
    """Render forecast as a styled matplotlib table (export-ready)."""
    fig, ax = plt.subplots(figsize=(10, 2.8))
    ax.axis("off")

    table_data = []
    for _, row in forecast_df.iterrows():
        conf = "High ✓" if forecast_df.index.get_loc(_) < 3 else "Medium"
        table_data.append([
            pd.Timestamp(row["date"]).strftime("%b %Y"),
            f"${row['forecast']:>12,.0f}",
            f"${row['lower']:>12,.0f}",
            f"${row['upper']:>12,.0f}",
            f"{row['seasonal_factor']:.2f}x",
            conf,
        ])

    col_labels = ["Month", "Forecast", "Lower (90%)",
                  "Upper (90%)", "Season", "Confidence"]
    tbl = ax.table(
        cellText=table_data,
        colLabels=col_labels,
        loc="center",
        cellLoc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10)
    tbl.scale(1, 1.6)

    # header styling
    for j in range(len(col_labels)):
        tbl[0, j].set_facecolor("#185FA5")
        tbl[0, j].set_text_props(color="white", fontweight="bold")

    # alternating row shading
    for i in range(1, len(table_data) + 1):
        bg = "#f4f8fd" if i % 2 == 0 else "white"
        for j in range(len(col_labels)):
            tbl[i, j].set_facecolor(bg)

    ax.set_title("6-Month Demand Forecast", fontsize=13,
                 fontweight="bold", pad=16)
    fig.tight_layout()
    return fig
