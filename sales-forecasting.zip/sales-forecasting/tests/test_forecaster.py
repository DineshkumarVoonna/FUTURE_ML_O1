"""
tests/test_forecaster.py
Unit tests for the forecasting engine.
Run with: pytest tests/
"""

import sys
import os
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from forecaster import (
    mape, load_and_prepare, compute_seasonal_index,
    train, evaluate, forecast_future, FEATURES,
)


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def synthetic_csv(tmp_path_factory):
    """Create a minimal synthetic CSV for testing (3 years of data)."""
    tmp = tmp_path_factory.mktemp("data")
    csv_path = tmp / "test_sales.csv"

    np.random.seed(0)
    season = [0.72,0.68,0.81,0.88,0.95,0.97,0.93,0.96,1.02,1.12,1.48,1.68]
    rows = []
    for i in range(36):
        date = pd.Timestamp("2022-01-01") + pd.DateOffset(months=i)
        base = 50000 * (1 + 0.15 * i / 12) * season[date.month - 1]
        for region in ["North", "South"]:
            for cat in ["Electronics", "Apparel"]:
                rows.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "product_category": cat,
                    "region": region,
                    "units_sold": max(1, int(base / 200 + np.random.randn() * 5)),
                    "revenue": round(base / 2 * (1 + np.random.randn() * 0.05), 2),
                    "marketing_spend": round(np.random.uniform(500, 3000), 2),
                    "discount_pct": round(np.random.uniform(0, 0.2), 3),
                    "returns": max(0, int(np.random.poisson(2))),
                })
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    return str(csv_path)


@pytest.fixture(scope="module")
def prepared_df(synthetic_csv):
    return load_and_prepare(synthetic_csv)


@pytest.fixture(scope="module")
def trained(prepared_df):
    return train(prepared_df, test_months=6)


# ── mape ─────────────────────────────────────────────────────────────────────

def test_mape_perfect():
    y = np.array([100.0, 200.0, 300.0])
    assert mape(y, y) == pytest.approx(0.0)

def test_mape_basic():
    y_true = np.array([100.0, 200.0])
    y_pred = np.array([110.0, 190.0])
    # (10/100 + 10/200) / 2 * 100 = 7.5
    assert mape(y_true, y_pred) == pytest.approx(7.5, rel=1e-3)

def test_mape_ignores_zero():
    y_true = np.array([0.0, 100.0])
    y_pred = np.array([50.0, 110.0])
    # only the second pair is used → 10%
    assert mape(y_true, y_pred) == pytest.approx(10.0, rel=1e-3)


# ── load_and_prepare ──────────────────────────────────────────────────────────

def test_prepared_has_expected_columns(prepared_df):
    for col in FEATURES + ["date", "revenue"]:
        assert col in prepared_df.columns, f"Missing column: {col}"

def test_prepared_no_nulls(prepared_df):
    assert prepared_df[FEATURES].isnull().sum().sum() == 0

def test_prepared_sorted(prepared_df):
    assert prepared_df["date"].is_monotonic_increasing

def test_filter_by_product(synthetic_csv):
    df_elec = load_and_prepare(synthetic_csv, product="Electronics")
    df_all  = load_and_prepare(synthetic_csv)
    assert df_elec["revenue"].sum() < df_all["revenue"].sum()

def test_filter_by_region(synthetic_csv):
    df_north = load_and_prepare(synthetic_csv, region="North")
    df_all   = load_and_prepare(synthetic_csv)
    assert df_north["revenue"].sum() < df_all["revenue"].sum()


# ── seasonal index ────────────────────────────────────────────────────────────

def test_seasonal_index_length(prepared_df):
    idx = compute_seasonal_index(prepared_df)
    assert len(idx) == 12

def test_seasonal_index_roughly_normalised(prepared_df):
    idx = compute_seasonal_index(prepared_df)
    # sum should be close to 12 (one per month, normalised)
    assert abs(idx.sum() - 12) < 0.5

def test_seasonal_index_all_positive(prepared_df):
    idx = compute_seasonal_index(prepared_df)
    assert (idx > 0).all()


# ── train / evaluate ──────────────────────────────────────────────────────────

def test_train_returns_three_objects(trained):
    model, train_df, test_df = trained
    assert model is not None
    assert len(train_df) > 0
    assert len(test_df) == 6

def test_train_split_sizes(prepared_df, trained):
    model, train_df, test_df = trained
    assert len(train_df) + len(test_df) == len(prepared_df)

def test_evaluate_metrics_keys(trained):
    model, _, test_df = trained
    metrics = evaluate(model, test_df)
    for key in ["mape", "rmse", "mae", "r2", "y_true", "y_pred", "residuals", "dates"]:
        assert key in metrics, f"Missing metric: {key}"

def test_evaluate_mape_reasonable(trained):
    model, _, test_df = trained
    metrics = evaluate(model, test_df)
    assert 0 <= metrics["mape"] < 50, "MAPE unreasonably large"

def test_evaluate_r2_range(trained):
    model, _, test_df = trained
    metrics = evaluate(model, test_df)
    assert -1 <= metrics["r2"] <= 1


# ── forecast_future ───────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def forecast(prepared_df, trained):
    model, _, _ = trained
    si = compute_seasonal_index(prepared_df)
    return forecast_future(model, prepared_df, si, horizon=6)

def test_forecast_horizon_length(forecast):
    assert len(forecast) == 6

def test_forecast_columns(forecast):
    for col in ["date", "forecast", "lower", "upper", "seasonal_factor"]:
        assert col in forecast.columns

def test_forecast_positive_values(forecast):
    assert (forecast["forecast"] >= 0).all()
    assert (forecast["lower"] >= 0).all()

def test_forecast_band_ordering(forecast):
    assert (forecast["lower"] <= forecast["forecast"]).all()
    assert (forecast["forecast"] <= forecast["upper"]).all()

def test_forecast_dates_future(prepared_df, forecast):
    last_hist = prepared_df["date"].max()
    assert (pd.to_datetime(forecast["date"]) > last_hist).all()

def test_forecast_band_widens(forecast):
    """Confidence band should grow or stay constant over the horizon."""
    widths = (forecast["upper"] - forecast["lower"]).values
    # at least the last width should be >= the first
    assert widths[-1] >= widths[0] * 0.9  # 10% tolerance

def test_seasonal_factor_range(forecast):
    assert (forecast["seasonal_factor"] > 0.5).all()
    assert (forecast["seasonal_factor"] < 2.0).all()


# ── edge cases ────────────────────────────────────────────────────────────────

def test_forecast_horizon_1(prepared_df, trained):
    model, _, _ = trained
    si = compute_seasonal_index(prepared_df)
    fc = forecast_future(model, prepared_df, si, horizon=1)
    assert len(fc) == 1

def test_forecast_horizon_12(prepared_df, trained):
    model, _, _ = trained
    si = compute_seasonal_index(prepared_df)
    fc = forecast_future(model, prepared_df, si, horizon=12)
    assert len(fc) == 12

def test_confidence_95(prepared_df, trained):
    model, _, _ = trained
    si = compute_seasonal_index(prepared_df)
    fc_90 = forecast_future(model, prepared_df, si, confidence=0.90)
    fc_95 = forecast_future(model, prepared_df, si, confidence=0.95)
    width_90 = (fc_90["upper"] - fc_90["lower"]).mean()
    width_95 = (fc_95["upper"] - fc_95["lower"]).mean()
    assert width_95 > width_90, "95% CI should be wider than 90%"
